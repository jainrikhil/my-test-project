var a = 0;
var b = 1;
var c = a + b;
console.log(c);