let Print = () => console.log("Hello TypeScript");

Print();